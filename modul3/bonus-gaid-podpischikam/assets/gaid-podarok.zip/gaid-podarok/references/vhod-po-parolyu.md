# Вход по паролю для гайда-подарка

## Честно о том, что это
Бесплатная страница (например, на GitHub Pages) – просто файл, своего сервера у неё нет. Поэтому пароль проверяется в браузере читателя. Такой вход:
- закрывает гайд от случайных людей, которым переслали ссылку без пароля;
- вместе с `noindex` просит поисковики не показывать страницу в поиске;
- **не защищает** от того, кто специально откроет код страницы или открытый репозиторий: текст гайда лежит там целиком. Короткий простой пароль к тому же подбирается перебором по хэшу.

Скажи это автору до того, как ставить вход. В гайд не кладём личные данные, платные материалы целиком и всё, что нельзя показывать всем. Если нужна настоящая защита – платформа с личным кабинетом или шифрование всей страницы паролем (у него свои неудобства: после каждой правки шифровать заново, забытый пароль не восстановить).

## Требования
1. Пока пароль не введён, виден только экран входа: метка, название гайда, фраза «Введите пароль из сообщения, где вы получили ссылку», поле, кнопка «Открыть гайд». Экран входа – в стиле страницы.
2. В коде только хэш SHA-256 пароля. Перед хэшированием пароль очищается от пробелов по краям и переводится в строчные буквы – так регистр при вводе не важен.
3. SHA-256 считается функцией на чистом JavaScript внутри страницы (ниже), чтобы вход работал и на сайте, и когда файл открыт с компьютера.
4. Неверный пароль – спокойное сообщение под полем, без перезагрузки.
5. После верного пароля в localStorage сохраняется хэш (не пароль) под ключом гайда. При следующем открытии страница открывается сразу. Сменили пароль – старый вход перестаёт действовать.
6. Ссылка `?k=пароль` открывает гайд сразу, запоминает вход и убирает ключ из адресной строки. Неверный ключ тоже убирается, показывается экран входа.
7. `<meta name="robots" content="noindex, nofollow">` в `<head>`.
8. Хранилище недоступно (инкогнито, встроенный браузер) – вход работает, просто без запоминания.
9. При печати экран входа скрыт.

## Как посчитать хэш
Считай кодом, не в уме. Python:
```python
import hashlib
print(hashlib.sha256("пароль".strip().lower().encode("utf-8")).hexdigest())
```
Не можешь запустить код – скажи об этом и попроси автора прислать готовый хэш. Сам пароль в код страницы не вставляй.

Проверка: для пароля `podarok` хэш равен `cc61d1221d02b1cd33f6c973abec50f0add84d21603f259d5eca62420de37208`.

## Готовый код (проверен)

### 1. В `<head>`, сразу после `<meta name="viewport">`
Заменить `ХЭШ_SHA256_ПАРОЛЯ` на хэш, `imya-gaida-vhod` – на своё имя латиницей (у каждого гайда своё).
```html
<meta name="robots" content="noindex, nofollow">
<!-- ВХОД ПО ПАРОЛЮ: начало -->
<style>
#gate{display:none}
html.locked body>*:not(#gate){display:none!important}
html.locked #gate{display:flex}
@media print{#gate{display:none!important}}
</style>
<script>
/* Пароль хранится не текстом, а хэшем SHA-256 (после обрезки пробелов и перевода в строчные буквы).
   Чтобы сменить пароль, замените hash. store – имя записи в браузере, у каждого гайда своё. */
var GATE={hash:'ХЭШ_SHA256_ПАРОЛЯ',store:'imya-gaida-vhod'};
function sha256(s){
  var K=[],H=[],p=2,n=0,i,j;
  function frac(x){return (x-Math.floor(x))*4294967296|0}
  while(n<64){for(j=2;j*j<=p;j++)if(p%j===0)break;if(j*j>p){if(n<8)H[n]=frac(Math.pow(p,1/2));K[n++]=frac(Math.pow(p,1/3));}p++;}
  var b=unescape(encodeURIComponent(s)),l=b.length,w=[];
  for(i=0;i<l;i++)w[i>>2]|=b.charCodeAt(i)<<(24-(i%4)*8);
  w[l>>2]|=0x80<<(24-(l%4)*8);w[((l+8>>6)<<4)+15]=l*8;
  for(i=0;i<w.length;i+=16){
    var a=H.slice(0),W=[];
    for(j=0;j<64;j++){
      if(j<16)W[j]=w[i+j]|0;else{var x=W[j-15],y=W[j-2];W[j]=(((x>>>7|x<<25)^(x>>>18|x<<14)^(x>>>3))+W[j-7]+((y>>>17|y<<15)^(y>>>19|y<<13)^(y>>>10))+W[j-16])|0;}
      var e=a[4],t1=a[7]+((e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7))+((e&a[5])^(~e&a[6]))+K[j]+W[j],c=a[0],
          t2=((c>>>2|c<<30)^(c>>>13|c<<19)^(c>>>22|c<<10))+((c&a[1])^(c&a[2])^(a[1]&a[2]));
      a=[(t1+t2)|0].concat(a);a[4]=(a[4]+t1)|0;a.pop();
    }
    for(j=0;j<8;j++)H[j]=(H[j]+a[j])|0;
  }
  var o='';for(i=0;i<8;i++)o+=('00000000'+(H[i]>>>0).toString(16)).slice(-8);return o;
}
function gateHash(p){return sha256(String(p||'').trim().toLowerCase());}
(function(){
  var ok=false;
  try{
    var q=new URLSearchParams(location.search),k=q.get('k');
    if(k!==null){
      if(gateHash(k)===GATE.hash){ok=true;try{localStorage.setItem(GATE.store,GATE.hash);}catch(e){}}
      q.delete('k');var qs=q.toString();
      try{history.replaceState(null,'',location.pathname+(qs?'?'+qs:'')+location.hash);}catch(e){}
    }
  }catch(e){}
  if(!ok){try{ok=localStorage.getItem(GATE.store)===GATE.hash;}catch(e){}}
  if(!ok)document.documentElement.classList.add('locked');
})();
</script>
<!-- ВХОД ПО ПАРОЛЮ: конец -->
```

### 2. Первым элементом в `<body>`
Классы и цвета подогнать под стиль страницы. Заголовок на экране входа – не `<h1>`, чтобы на странице был один главный заголовок.
```html
<div id="gate" role="dialog" aria-modal="true" aria-labelledby="gate-title">
  <form class="gbox" id="gate-form">
    <p class="label">Гайд-подарок</p>
    <p class="gtitle" id="gate-title">[Название гайда]</p>
    <p>Введите пароль из сообщения, где вы получили ссылку.</p>
    <label for="gate-pass" class="label">Пароль</label>
    <input id="gate-pass" type="password" autocomplete="current-password" autocapitalize="none" spellcheck="false">
    <p class="gerr" id="gate-err" aria-live="polite"></p>
    <button class="btn" type="submit">Открыть гайд</button>
  </form>
</div>
```
Стили экрана входа, например:
```css
#gate{position:fixed;inset:0;z-index:50;align-items:center;justify-content:center;padding:20px;background:[тёмный цвет страницы]}
.gbox{width:100%;max-width:440px;background:[цвет фона страницы];padding:30px 24px 26px;border-top:6px solid [цвет акцента]}
.gbox input{display:block;width:100%;font:inherit;font-size:17px;padding:13px 14px;border:1.5px solid [цвет линий]}
.gerr{min-height:24px;margin-top:10px;font-weight:600;color:[цвет ошибки]}
```

### 3. В конце `<body>`, в общем `<script>`
```js
  /* вход по паролю */
  var form=document.getElementById('gate-form');
  if(form)form.addEventListener('submit',function(ev){
    ev.preventDefault();
    var inp=document.getElementById('gate-pass'),err=document.getElementById('gate-err');
    if(gateHash(inp.value)===GATE.hash){
      try{localStorage.setItem(GATE.store,GATE.hash);}catch(e){}
      document.documentElement.classList.remove('locked');
      err.textContent='';window.scrollTo(0,0);
    }else{
      err.textContent='Пароль не подошёл. Проверьте раскладку клавиатуры и попробуйте ещё раз.';
      inp.select();
    }
  });
  if(document.documentElement.classList.contains('locked')){var gp=document.getElementById('gate-pass');if(gp)gp.focus();}
```

## Как проверить
1. Открыть страницу – виден только экран входа.
2. Ввести неверный пароль – сообщение под полем, гайд закрыт.
3. Ввести верный пароль (можно с заглавными буквами) – гайд открылся.
4. Перезагрузить страницу – гайд открывается сразу.
5. В окне инкогнито открыть адрес с `?k=пароль` – гайд открылся, ключ исчез из адресной строки.
6. В окне инкогнито открыть адрес с неверным `?k=` – экран входа.
